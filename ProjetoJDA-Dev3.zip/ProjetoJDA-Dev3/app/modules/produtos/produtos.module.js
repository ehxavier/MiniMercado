(function () {
    angular.module('MiniMercado.Produtos', []);
})();
