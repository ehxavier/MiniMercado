(function () {
    angular.module('MiniMercado.Principal', []);
})();
