(function () {
    angular.module('MiniMercado.Usuarios', []);
})();
