<?php
$conn = mysql_connect("localhost:3306", "root", "");
mysql_select_db('minimercado', $conn);

#interno
#mysql11.redehost.com.br:41890
#externo
#mysql11.redehost.com.br:3306